package com.company;

public class Main extends J{

    public static void main(String[] args) {
    }
}

